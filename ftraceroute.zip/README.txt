﻿Traceroute 
	версия 0.8 
Автор
 	Коробейников Николай
	Ссылки:  	vk.com/hypelive
			empils48@gmail.com
Описание
	Утилита для отслеживания пути следования пакета 
Требования
	Python версии >=3.6
	прописать в консоли : “ netsh advfirewall firewall add rule name="All ICMP v4" dir=in action=allow protocol=icmpv4:any,any” , чтобы можно было принимать ICMP ответы
Состав
	Консольная версия - Ftraceroute.py
Консольная версия
	Для вывода справки введите: Ftraceroute.py -h
Детали реализации
	soon
